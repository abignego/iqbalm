

const Faq = () => {
  return (
    <div>Faq</div>
  )
}

export default Faq