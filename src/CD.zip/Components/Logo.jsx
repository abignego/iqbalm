import React from "react";
import {FireFilled} from '@ant-design/icons'
const Logo  = () =>{
    return (
        <div className="logo">
            <div className="logo-icon">
            <FireFilled/>
            </div>
            
        </div>
    )
}
//https://www.youtube.com/watch?v=-e3-wtPmGLg
export default Logo