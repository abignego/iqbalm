//import { Layout } from 'antd'
import {Routes, Route} from "react-router-dom";
import HomePages from './Pages/HomePages';
import TestimonialPage from './Pages/TestimonialPage';
import DataPage from "./Pages/DataPage";
import NotFound from "./Pages/NotFound";


function App() {

  return (
  <>
  <div>
    
    <Routes>
      <Route path='/' Component={HomePages}/>
      <Route path='/testimonial' Component={TestimonialPage}/>
      <Route path='/Data' Component={DataPage}/>
      <Route path='*' Component={NotFound}/>


  
    </Routes>
  </div>
  


    
    </>
    );
}

export default App
