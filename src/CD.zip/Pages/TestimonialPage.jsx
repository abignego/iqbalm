

const TestimonialPage = () => {
  return (
    <div>TestimonialPage</div>
  )
}

export default TestimonialPage