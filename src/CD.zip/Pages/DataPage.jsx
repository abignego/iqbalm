

const DataPage = () => {
  return (
    <div>DataPage</div>
  )
}

export default DataPage