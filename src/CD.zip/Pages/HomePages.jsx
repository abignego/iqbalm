 

const HomePages = () => {
  return (
    <div>HomePages</div>
  )
}

export default HomePages