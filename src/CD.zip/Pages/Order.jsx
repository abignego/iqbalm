

const Order = ()=> {

    return(<>

    <h1>asd</h1>
    </>
        
    )
}
export default Order