const SyaratKetentuan = () => {
  return (
    <div>SyaratKetentuan</div>
  )
}

export default SyaratKetentuan