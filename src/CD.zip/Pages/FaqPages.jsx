

const FaqPages = () => {
  return (
    <div>FaqPages</div>
  )
}

export default FaqPages